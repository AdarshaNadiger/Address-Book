#include "contact.h"
#include<string.h>




void loaddata(AddressBook *addressBook)
{
    FILE *f = fopen("data.csv", "r");
    if (f == NULL)
    {
        printf("Error in opening file. File might not exist, or is corrupted.\n");
        return;
    }

    char line[1000];
    int count = 0;
    addressBook->contactCount = 0;  // Reset contact count before loading

    while (fgets(line, sizeof(line), f))
    {
        // Skip the first line (which contains the number of contacts)
        if (count == 0)
        {
            count++;
            continue;
        }

        // Skip empty lines
        if (strlen(line) == 0 || strcmp(line, "\n") == 0)
            continue;

        char name[50], phone[20], email[50];

        // Parse contact information
        if (sscanf(line, "%[^,],%[^,],%s", name, phone, email) == 3)
        {
            strcpy(addressBook->contacts[addressBook->contactCount].name, name);
            strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
            strcpy(addressBook->contacts[addressBook->contactCount].email, email);
            addressBook->contactCount++;
        }
    }

    fclose(f);
    printf("Contacts loaded successfully from file.\n");
}

void listContacts(AddressBook *addressBook)
{
    printf("\033[0;33m");
    printf("---------------------------------------------------------------------------------------\n");
    printf("| Sl.No |        Name        |     Phone Number     |           Email id            |\n");
    printf("---------------------------------------------------------------------------------------\n");
    
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        printf("| %6d | %-20s | %-20s | %-30s |\n", 
               i + 1, 
               addressBook->contacts[i].name, 
               addressBook->contacts[i].phone, 
               addressBook->contacts[i].email);
    }
    
    printf("---------------------------------------------------------------------------------------\n");
    printf("\033[0m");
}





void createContact(AddressBook *addressBook)
{
    printf("\033[0;40m");
    
    char name[50];
    int valid = 0;
    while (!valid)
    {
        valid = 1; 
        printf("Enter the Name: ");
        scanf(" %[^\n]", name);

        for (int i = 0; name[i] != '\0'; i++)
        {
            if ((name[i] < 'a' || name[i] > 'z') && (name[i] < 'A' || name[i] > 'Z') && name[i] != ' ')
            {
                valid = 0;
                printf("\t\t::Invalid name! Please enter only alphabetic characters::\n");
                break;
            }
        }
    }
    strcpy(addressBook->contacts[addressBook->contactCount].name, name);
    //printf("Name: %s\n", name);

    char phone_no[11];
    int key = 0;
    while (!key)
    {
        key = 1; 
        int length = 0;

        printf("Enter the Phone no (10 digits): ");
        scanf(" %[^\n]", phone_no);

        for (int i = 0; phone_no[i] != '\0'; i++)
        {
            if (phone_no[i] < '0' || phone_no[i] > '9')
            {
                key = 0;
                printf("\t\t::Your entered number contains non-numeric characters::\n");
                break;
            }
            length++;
        }
        if (length != 10)
        {
            key = 0;
            printf("\t\t::Invalid number! Entered number does not contain exactly 10 digits::\n");
        }

        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(addressBook->contacts[i].phone, phone_no) == 0)
            {
                key = 0;
                printf("\t\t::Phone number already exists! Please enter a unique number::\n");
                break;
            }
        }
    }

    strcpy(addressBook->contacts[addressBook->contactCount].phone, phone_no);
    //printf("Phone no: %s\n", phone_no);

    char email[100];
    int email_valid = 0;
    while (email_valid == 0)
    {
        printf("Enter the Email: ");
        scanf(" %[^\n]", email);

        int at_found = 0, dotcom_found = 0, at_position = -1, dotcom_position = -1;

        for (int i = 0; email[i] != '\0'; i++)
        {
            if (email[i] == '@')
            {
                at_found = 1;
                at_position = i;
            }
            else if (i >= 4 && email[i-3] == '.' && email[i-2] == 'c' && email[i-1] == 'o' && email[i] == 'm')
            {
                dotcom_found = 1;
                dotcom_position = i;
            }
        }

        if (at_found && dotcom_found && dotcom_position > at_position + 1)
        {
            email_valid = 1;
            strcpy(addressBook->contacts[addressBook->contactCount].email, email);
            printf("Email: %s\n", email);
        }
        else
        {
            printf("Invalid email format. Please enter a valid email.\n");
        }
    }

    addressBook->contactCount++;
}

void searchContact(AddressBook *addressBook)
{
 printf("\033[0;28m");	
 int opt;
 printf("search a contcat by follwing:\n");//searching contact by 3 options
 printf("1.Name\n2.Phone\n3.Email\n");
 printf("choose one option: ");
 scanf("%d",&opt);
 int flag=0;
 int index=0;
 switch(opt)
   {
        case 1:
            getchar();
            char name[50];
            int count=0;
            printf("enter a name to search: ");
            scanf("%[^\n]",name);//reading name from user
            int len=strlen(name);
            for(int k=0;name[k]!='\0';k++)
            {
                if(!((name[k]>='a'&&name[k]<='z')||(name[k]>='A'&&name[k]<='Z')))//checking name should contain characters
                {
                    flag=0;
                    break;
                }
            }
            if(flag==0)
            {
                opt=0;
            }
            for(int i=0;i<addressBook->contactCount;i++)
            {   
                flag=1;
                char str[30];
                strcpy(str,(addressBook->contacts[i].name));
                for(int j=0;j<len;j++)
                {
                if(str[j]!=name[j])//checking with first letters with names
                {
                    flag=0;
                    break;
                }
                }
            
            if(flag==1)
            {
                count++;//counting multple same contacts 
                index=i;
                flag=1;
                printf("%s %s %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            }
            else
            {
                flag=0;
            }
            }
            if(count==1)
            {
               //printf("%s %s %s\n",addressBook->contacts[index].name,addressBook->contacts[index].phone,addressBook->contacts[index].email);
                printf("\033[0;32mcontact found\033[0m\n");
            }
            if(count>1)
            {   
                printf("multiple contacts are found\n");//multiple charactrs found then go throug phone
                printf("please enter a mobile number: \n");
                goto phone;   
            }
            if(flag==0)
            {
                printf("\033[0;31mcontact not found\033[0m\n");
            }
            break;
        case 2:
            phone:getchar();
            flag=0;
            char phone[50];
            printf("enter a phone number to search : ");
            scanf("%[^\n]",phone);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(!(strcmp(phone,addressBook->contacts[i].phone)))//checking previous phone numbers
                {
                    flag=1;
                    
                }
                if(flag==1)
                {
                    printf("%s %s %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                    break;
                }
            }
            if(flag==0) 
            {
                printf("\033[0;31mphone number not found:\033[0m\n");
            }
            else{
                printf("\033[0;32mphone number found\033[0m\n");
            }
            break;
        case 3:
            email:getchar();
            flag=0;
            char email[50];
            printf("enter a email to search: ");
            scanf("%[^\n]",email);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(!(strcmp(email,addressBook->contacts[i].email)))//checking previous email there or not
                {
                    flag=1;
                    
                }
                if(flag==1)
                {
                    printf("%s %s %s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                    break;
                }
            }
            if(flag==0)
            {
                printf("\033[0;31mEmail not found:\033[0m\n");
            }
            else
            {
                printf("\033[0;32mEmail is found\033[0m\n");
            }
            break;
        default:
            printf("\033[0;31mInvlaid input\033[0m\n");
    }
}

void editContact(AddressBook *addressBook)
{   
    char searchName[50];
    int foundIndex = -1;

    printf("Enter the Name of the contact you want to edit: ");
    scanf(" %[^\n]", searchName);
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(addressBook->contacts[i].name, searchName) == 0)
        {
            foundIndex = i;
            break;
        }
    }

    if (foundIndex < 0)
    {
        printf("Contact with the name '%s' not found.\n", searchName);
        return;
    }
    printf("What do you want to edit?\n1 - Name\n2 - Phone Number\n3 - Email Address\nChoose an option: ");
    int option;
    scanf("%d", &option);

    switch (option)
    {
        case 1: {
            printf("Enter the new Name: ");
            scanf(" %[^\n]", addressBook->contacts[foundIndex].name);
            printf("Name updated successfully.\n");
            break;
        }

        case 2: {

            char newPhone[11];
            printf("Enter the new 10-digit Phone Number: ");
            scanf(" %10s", newPhone);

            if (strlen(newPhone) == 10 && strspn(newPhone, "0123456789") == 10)
            {
                strcpy(addressBook->contacts[foundIndex].phone, newPhone);
                printf("Phone number updated successfully.\n");
            }
            else
            {
                printf("Invalid phone number. It must be 10 digits.\n");
            }
            break;
        }

        case 3: {
            char newEmail[100];
            printf("Enter the new Email: ");
            scanf(" %[^\n]", newEmail);
            if (strchr(newEmail, '@') && strstr(newEmail, ".com"))
            {
                strcpy(addressBook->contacts[foundIndex].email, newEmail);
                printf("Email updated successfully.\n");
            }
            else
            {
                printf("Invalid email format. Please enter a valid email.\n");
            }
            break;
        }
        default:
            printf("Invalid option. Please choose 1, 2, or 3.\n");
            break;
    }
    
}

void deleteContact(AddressBook *addressBook)
{   
    printf("\033[0;39m");
    int opt;
    printf("\t\t\tDeleteing the contact\t\t\t\n");
    printf("1.name\n2.phone number\n3.email\n");
    printf("choose one option: ");
    scanf("%d",&opt);
    int flag=1;
     switch(opt)
    {
        case 1:
            getchar();
            char name[50];
            int count=0;
            int index=0;
            printf("enter name which you want delete: ");
            scanf("%[^\n]",name);
            int len=strlen(name);
            for(int k=0;name[k]!='\0';k++)
            {
                if(!((name[k]>='a'&&name[k]<='z')||(name[k]>='A'&&name[k]<='Z')))
                {
                    flag=0;
                    break;
                }
            }
            if(flag==0)
            {
                opt=0;
            }
            for(int i=0;i<addressBook->contactCount;i++)
            {   
                flag=1;
                char str[30];
                strcpy(str,addressBook->contacts[i].name);
                for(int j=0;j<len;j++)
                {
                if(str[j]!=name[j])
                {
                    flag=0;
                    break;
                }
                }
            if(flag==1)
            {
                count++;
                index=i;
            }
            }
            
            if(count==1)
            {
                  flag=1;
                  for(int i=index;i<addressBook->contactCount;i++)
                  {
                            strcpy(addressBook->contacts[i].name,addressBook->contacts[i+1].name);
                            strcpy(addressBook->contacts[i].phone,addressBook->contacts[i+1].phone);
                            strcpy(addressBook->contacts[i].email,addressBook->contacts[i+1].email);
                  }
                   
            }
            if(count>1)
            {   int op;
                printf("mulitple contacts are found \n");
                printf("go through\n 1.phone\n2.email\n");
                printf("select one option: ");
                scanf("%d",&op);
                switch(op)
                {
                    case 1:
                        goto phone;
                        break;
                    case 2:
                        goto email;
                }
            }
            if(flag==0)
            {
                printf("Name not found\n");
            }
            else
            {
            printf("Deleted successfully...\n");
            (addressBook->contactCount)--;
            }
            break;
        case 2:
            phone:getchar();
            char phone[50];
            printf("enter a phone number which you want delete: ");
            scanf("%[^\n]",phone);
                for(int i=0;i<addressBook->contactCount;i++)
                {
                    if(!(strcmp(phone,addressBook->contacts[i].phone)))
                    {
                        flag=1;
                        for(int j=i;j<addressBook->contactCount;j++)
                        {
                        strcpy(addressBook->contacts[j].name,addressBook->contacts[j+1].name);
                        strcpy(addressBook->contacts[j].phone,addressBook->contacts[j+1].phone);
                        strcpy(addressBook->contacts[j].email,addressBook->contacts[j+1].email);
                    
                        }
                    }
                }
                    if(flag==0)
                    {
                        printf("phone number not found\n");
                    }
                    else
                    {
                    printf("Deleted successfully...");
                    (addressBook->contactCount)--;
                    }
            break;  
        case 3:
            email:getchar();
            char email[50];
            printf("entera email which you want delete: ");
            scanf("%[^\n]",email);
                for(int i=0;i<addressBook->contactCount;i++)
                {
                    if(!(strcmp(email,addressBook->contacts[i].email)))
                    {
                        flag=1;
                        for(int j=i;j<addressBook->contactCount;j++)
                        {
                            flag=1;
                            strcpy(addressBook->contacts[j].name,addressBook->contacts[j+1].name);
                            strcpy(addressBook->contacts[j].phone,addressBook->contacts[j+1].phone);
                            strcpy(addressBook->contacts[j].email,addressBook->contacts[j+1].email);
                        }

                    }
                }
                    if(flag==0)
                    {
                        printf("email number not found\n");
                    }
                    else
                    {   
                        printf("Deleted successfully...\n");
                        (addressBook->contactCount)--;
                    }
            break;   
    }
}



void save_and_exit(AddressBook *addressBook)
{
    FILE *fptr = fopen("data.csv", "w");  // "w" overwrites the file
    if (fptr == NULL)
    {
        printf("Error in opening file for writing.\n");
        return;
    }

    // Write the number of contacts
    fprintf(fptr, "Number of contacts: %d\n", addressBook->contactCount);

    for (int i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(fptr, "%s,%s,%s\n", addressBook->contacts[i].name,
                                    addressBook->contacts[i].phone,
                                    addressBook->contacts[i].email);
    }

    fclose(fptr);
    printf("Contacts saved successfully.\n");
}


