#include "contact.h"
#include <stdio.h>

int main() {
    AddressBook addressBook;
    loaddata(&addressBook);

    int choice;
    char continueChoice;
    int i;

    do {
        printf("\033[0;31m");
        printf("\t\t\t:::WELCOME TO ADDRESS BOOK PROJECT:::\n");
        printf("\033[0;36m");
        printf("Address Book Menu:\n");
        printf("1. Create Contact\n");
        printf("2. Search Contact\n");
        printf("3. Edit Contact\n");
        printf("4. Delete Contact\n");
        printf("5. List Contacts\n");
        printf("6. Save And Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar();
	

        switch (choice) {
            case 1:
                createContact(&addressBook);
                break;
            case 2:
                searchContact(&addressBook);
                break;
            case 3:
                editContact(&addressBook);
                break;
            case 4:
                deleteContact(&addressBook);
                break;
            case 5:
                listContacts(&addressBook);
                break;
            case 6:
                save_and_exit(&addressBook);
                return 0; 

            default:
                printf("Invalid choice! Please try again.\n");
                continue; // Skip the prompt to continue
        }

        // Ask if the user wants to continue
	  printf("\033[0;39m");
        printf("Do you want to continue? \nenter:1\nExit:0: ");
        scanf(" %d", &i);
        getchar(); 

    } while (i);

    return 0;
}
 
